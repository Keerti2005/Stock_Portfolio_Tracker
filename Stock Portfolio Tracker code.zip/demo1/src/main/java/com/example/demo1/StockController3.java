package com.example.demo1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

public class StockController3 implements Initializable {
    private Stage primaryStage;
    private Scene scene;
    private Parent root;

    public void switchtoscene4(ActionEvent event) throws IOException {
        Parent root= FXMLLoader.load(getClass().getResource("stock3.fxml"));
        primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    public void switchtoscene7(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("stock7.fxml"));
        primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    public void switchtoscene9(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("stock9.fxml"));
        primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    @FXML
    private TableColumn<?, ?> amount3;

    @FXML
    private LineChart<?, ?> chartt3;

    @FXML
    private TableColumn<?, ?> current3;

    @FXML
    private TableColumn<?, ?> day3;



    @FXML
    private TableColumn<?, ?> max3;

    @FXML
    private TableColumn<?, ?> maxl3;

    @FXML
    private TableColumn<?, ?> overall3;

    @FXML
    private AnchorPane pane3;

    @FXML
    private TableView<Model2> table3;

    private Connection connect;
    private PreparedStatement prepare;

    private ResultSet result;
    public Connection connectDb() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/stock_portfolio", "root", "root@123");

            return con;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void chart() {
        String chartSQl = "SELECT * FROM stock_portfolio3";


        connect = connectDb();
        try {
            XYChart.Series chartData = new XYChart.Series();

            prepare = connect.prepareStatement(chartSQl);

            result = prepare.executeQuery();

            while (result.next()) {
                chartData.getData().add(new XYChart.Data(result.getString(2), result.getInt(3)));


            }
            chartt3.getData().add(chartData);
        } catch (Exception e) {
            e.printStackTrace();

        }


    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        chart();
        amount3.setCellValueFactory(new PropertyValueFactory<>("Amount"));
        current3.setCellValueFactory(new PropertyValueFactory<>("Current"));
        day3.setCellValueFactory(new PropertyValueFactory<>("Day"));
        overall3.setCellValueFactory(new PropertyValueFactory<>("Overall"));
        max3.setCellValueFactory(new PropertyValueFactory<>("Max"));
        maxl3.setCellValueFactory(new PropertyValueFactory<>("Maxl"));
        table3.setItems(observableList);

    }


    ObservableList<Model2> observableList= FXCollections.observableArrayList(
            new Model2(1000.00, 100.50, 50.70, 50.50, 120.20,00.75)
    );


}


