package com.example.demo1;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;

public class Model {
    private SimpleStringProperty company;
    private SimpleDoubleProperty price;
    private SimpleDoubleProperty diff;
    private SimpleDoubleProperty buy;
    private SimpleDoubleProperty sell;

    public Model(String company, double price,double diff, double buy, double sell) {
        this.company =new SimpleStringProperty(company);
        this.price = new SimpleDoubleProperty(price);
        this.diff = new SimpleDoubleProperty(diff);
        this.buy = new SimpleDoubleProperty(buy);
        this.sell = new SimpleDoubleProperty(sell);
    }

    public String getCompany() {

        return company.get();
    }

    public void setCompany(String company) {
        this.company =new SimpleStringProperty(company);
    }

    public double getPrice() {
        return price.get();
    }

    public void setPrice(double price) {
        this.price = new SimpleDoubleProperty(price);
    }

    public double getDiff() {
        return diff.get();
    }

    public void setDiff(double diff) {
        this.diff = new SimpleDoubleProperty(diff);
    }

    public double getBuy() {
        return buy.get();
    }

    public void setBuy(double buy) {
        this.buy = new SimpleDoubleProperty(buy);
    }

    public double getSell() {
        return sell.get();
    }

    public void setSell(double sell) {
        this.sell = new SimpleDoubleProperty(sell);
    }







}
