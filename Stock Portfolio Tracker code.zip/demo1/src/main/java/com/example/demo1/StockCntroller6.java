package com.example.demo1;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class StockCntroller6 {

    @FXML
    private TextField bankField;

    @FXML
    private TextField branchField;

    @FXML
    private TextField accountNumberField;

    @FXML
    private TextField amountField;

    @FXML
    private TextField ifscField;

    @FXML
    private Button buyButton;

    @FXML
    private Button sellButton;

    @FXML
    private void initialize() {
        // Set up event handlers for the buy and sell buttons
        buyButton.setOnAction(event -> handleTransaction("Buy"));
        sellButton.setOnAction(event -> handleTransaction("Sell"));
    }

    private void handleTransaction(String transactionType) {
        String bankName = bankField.getText();
        String branch = branchField.getText();
        String accountNumber = accountNumberField.getText();
        String amount = amountField.getText();
        String ifscCode = ifscField.getText();

        // Placeholder logic for validation
        if (bankName.isEmpty() || branch.isEmpty() || accountNumber.isEmpty() || amount.isEmpty() || ifscCode.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "All fields are required.");
        } else {
            // Placeholder logic for successful transaction
            showAlert(Alert.AlertType.INFORMATION, "Success", transactionType + " transaction successful!");
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}