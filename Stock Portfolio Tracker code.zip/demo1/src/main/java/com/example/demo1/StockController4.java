package com.example.demo1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

public class StockController4 implements Initializable {
    private Stage primaryStage;
    private Scene scene;
    private Parent root;

    public void switchtoscene6(ActionEvent event) throws IOException {
        Parent root= FXMLLoader.load(getClass().getResource("stock6.fxml"));
        primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    public void switchtoscene8(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("stock8.fxml"));
        primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    public void switchtoscene9(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("stock9.fxml"));
        primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    @FXML
    private TableColumn<?, ?> amount4;

    @FXML
    private LineChart<?, ?> chartt4;

    @FXML
    private TableColumn<?, ?> current4;

    @FXML
    private TableColumn<?, ?> day4;



    @FXML
    private TableColumn<?, ?> max4;

    @FXML
    private TableColumn<?, ?> maxl4;

    @FXML
    private TableColumn<?, ?> overall4;

    @FXML
    private AnchorPane pane4;

    @FXML
    private TableView<Model2> table4;

    private Connection connect;
    private PreparedStatement prepare;

    private ResultSet result;
    public Connection connectDb() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/stock_portfolio", "root", "root@123");

            return con;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void chart() {
        String chartSQl = "SELECT * FROM stock_portfolio4";


        connect = connectDb();
        try {
            XYChart.Series chartData = new XYChart.Series();

            prepare = connect.prepareStatement(chartSQl);

            result = prepare.executeQuery();

            while (result.next()) {
                chartData.getData().add(new XYChart.Data(result.getString(2), result.getInt(3)));


            }
            chartt4.getData().add(chartData);
        } catch (Exception e) {
            e.printStackTrace();

        }


    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        chart();
        amount4.setCellValueFactory(new PropertyValueFactory<>("Amount"));
        current4.setCellValueFactory(new PropertyValueFactory<>("Current"));
        day4.setCellValueFactory(new PropertyValueFactory<>("Day"));
        overall4.setCellValueFactory(new PropertyValueFactory<>("Overall"));
        max4.setCellValueFactory(new PropertyValueFactory<>("Max"));
        maxl4.setCellValueFactory(new PropertyValueFactory<>("Maxl"));
        table4.setItems(observableList);

    }


    ObservableList<Model2> observableList= FXCollections.observableArrayList(
            new Model2(60000.00, 17500.50, 500.90, 870.50, 1870.20,-270.75)
    );


}


