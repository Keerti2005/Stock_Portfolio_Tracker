package com.example.demo1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

public class GraphController implements Initializable {
    private Stage primaryStage;
    private Scene scene;
    private Parent root;
    public void switchtoscene2(ActionEvent event) throws IOException {
        Parent root= FXMLLoader.load(getClass().getResource("stock2.fxml"));
        primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    public void switchtoscene4(ActionEvent event) throws IOException {
        Parent root= FXMLLoader.load(getClass().getResource("stock4.fxml"));
        primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    public void switchtoscene9(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("stock9.fxml"));
        primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    @FXML
    private LineChart<?, ?> chartt;


    public TableView<Model2> table2;
    public TableColumn<Model2,Double> amount;
    public TableColumn<Model2,Double> current;
    public TableColumn <Model2,Double> overall;
    public TableColumn <Model2,Double> day;
    public TableColumn <Model2,Double> max;
    public TableColumn <Model2,Double> maxl;

    @FXML
    private AnchorPane pane;
private Connection connect;
private PreparedStatement prepare;

private ResultSet result;
public Connection connectDb() {
    try {
        Class.forName("com.mysql.cj.jdbc.Driver");

        Connection con = DriverManager.getConnection("jdbc:mysql://localhost/stock_portfolio", "root", "root@123");

        return con;
    } catch (Exception e) {
        e.printStackTrace();
        return null;
    }
}

public void chart() {
        String chartSQl = "SELECT * FROM stock_portfolio1";


        connect = connectDb();
        try {
            XYChart.Series chartData = new XYChart.Series();

            prepare = connect.prepareStatement(chartSQl);
           ;
            result = prepare.executeQuery();

            while (result.next()) {
                chartData.getData().add(new XYChart.Data(result.getString(2), result.getInt(3)));


            }
            chartt.getData().add(chartData);
        } catch (Exception e) {
            e.printStackTrace();

        }


    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        chart();
        amount.setCellValueFactory(new PropertyValueFactory<>("Amount"));
        current.setCellValueFactory(new PropertyValueFactory<>("Current"));
        day.setCellValueFactory(new PropertyValueFactory<>("Day"));
        overall.setCellValueFactory(new PropertyValueFactory<>("Overall"));
        max.setCellValueFactory(new PropertyValueFactory<>("Max"));
        maxl.setCellValueFactory(new PropertyValueFactory<>("Maxl"));
        table2.setItems(observableList);

    }





    public void switchtoscene5(ActionEvent event) throws IOException {
        Parent root= FXMLLoader.load(getClass().getResource("stock5.fxml"));
        primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();

    }



    ObservableList<Model2> observableList= FXCollections.observableArrayList(
            new Model2(10000.00, 10500.50, 500.00, 500.50, 1200.20,-300.75)
    );


}


