package com.example.demo1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

public class StockController2 implements Initializable {
    private Stage primaryStage;
    private Scene scene;
    private Parent root;
    public void switchtoscene3(ActionEvent event) throws IOException {
        Parent root= FXMLLoader.load(getClass().getResource("stock3.fxml"));
        primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    public void switchtoscene6(ActionEvent event) throws IOException {
        Parent root= FXMLLoader.load(getClass().getResource("stock6.fxml"));
        primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    public void switchtoscene9(ActionEvent event) throws IOException {
        Parent root= FXMLLoader.load(getClass().getResource("stock9.fxml"));
        primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    @FXML
    private TableColumn<?, ?> amount2;

    @FXML
    private LineChart<?, ?> chartt2;

    @FXML
    private TableColumn<?, ?> current2;

    @FXML
    private TableColumn<?, ?> day2;


    @FXML
    private TableColumn<?, ?> max2;

    @FXML
    private TableColumn<?, ?> maxl2;

    @FXML
    private TableColumn<?, ?> overall2;

    @FXML
    private AnchorPane pane2;

    @FXML
    private TableView<Model2> table2;


    private Connection connect;
    private PreparedStatement prepare;

    private ResultSet result;
    public Connection connectDb() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/stock_portfolio", "root", "root@123");

            return con;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void chart() {
        String chartSQl = "SELECT * FROM stock_portfolio2";


        connect = connectDb();
        try {
            XYChart.Series chartData = new XYChart.Series();

            prepare = connect.prepareStatement(chartSQl);

            result = prepare.executeQuery();

            while (result.next()) {
                chartData.getData().add(new XYChart.Data(result.getString(2), result.getInt(3)));


            }
            chartt2.getData().add(chartData);
        } catch (Exception e) {
            e.printStackTrace();

        }


    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        chart();
        amount2.setCellValueFactory(new PropertyValueFactory<>("Amount"));
        current2.setCellValueFactory(new PropertyValueFactory<>("Current"));
        day2.setCellValueFactory(new PropertyValueFactory<>("Day"));
        overall2.setCellValueFactory(new PropertyValueFactory<>("Overall"));
        max2.setCellValueFactory(new PropertyValueFactory<>("Max"));
        maxl2.setCellValueFactory(new PropertyValueFactory<>("Maxl"));
        table2.setItems(observableList);

    }


    ObservableList<Model2> observableList= FXCollections.observableArrayList(
            new Model2(18007.90,1500.50, 300.70, 500.50, 1280.20,-380.75)
    );


}


