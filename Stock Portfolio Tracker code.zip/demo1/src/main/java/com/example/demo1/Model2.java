package com.example.demo1;

import javafx.beans.property.SimpleDoubleProperty;

public class Model2 {
    private SimpleDoubleProperty amount;
    private SimpleDoubleProperty current;
    private SimpleDoubleProperty overall;
    private SimpleDoubleProperty day;
    private SimpleDoubleProperty max ;
    private SimpleDoubleProperty maxl;

    public Model2(double amount, double current, double overall,double day, double max, double maxl) {
        this.amount = new SimpleDoubleProperty(amount);
        this.current = new SimpleDoubleProperty(current);
        this.overall = new SimpleDoubleProperty(overall);
        this.day = new SimpleDoubleProperty(day);
        this.max = new SimpleDoubleProperty(max);
        this.maxl = new SimpleDoubleProperty(maxl);
    }


    public Double getAmount() {

        return amount.get();
    }
    public void setAmount(double amount) {
        this.amount = new SimpleDoubleProperty(amount);
    }


    public Double getCurrent() {

        return current.get();

    }


    public void setCurrent(double current) {
        this.current = new SimpleDoubleProperty(current);
    }


    public Double getOverall() {

        return overall.get();

    }


    public void setOverall(double overall) {
        this.overall = new SimpleDoubleProperty(overall);
    }


    public Double getDay() {

        return day.get();
    }
    public void setDay(double day) {
        this.day = new SimpleDoubleProperty(day);
    }


    public Double getMax() {

        return max.get();
    }

    public void setMax(double max) {
        this.max = new SimpleDoubleProperty(max);
    }

    public Double getMaxl() {

        return maxl.get();
    }

    public void setMaxl(double maxl) {
        this.maxl= new SimpleDoubleProperty(maxl);
    }






















}
