package com.example.demo1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class StockController implements Initializable {
    private Stage primaryStage;
    private Scene scene;
    private Parent root;
    public void switchtoscene3(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("stock3.fxml"));
        primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public void switchtoscene4(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("stock4.fxml"));
        primaryStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();
    }


        public void switchtoscene6(ActionEvent event) throws IOException {
            Parent root= FXMLLoader.load(getClass().getResource("stock6.fxml"));
            primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
            scene=new Scene(root);
            primaryStage.setScene(scene);
            primaryStage.show();
    }
        public void switchtoscene7(ActionEvent event) throws IOException {
            Parent root= FXMLLoader.load(getClass().getResource("stock7.fxml"));
            primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
            scene=new Scene(root);
            primaryStage.setScene(scene);
            primaryStage.show();
    }
    public void switchtoscene8(ActionEvent event) throws IOException {
        Parent root= FXMLLoader.load(getClass().getResource("stock8.fxml"));
        primaryStage=(Stage)((Node)event.getSource()).getScene().getWindow();
        scene=new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    public TableView<Model> table;
   public TableColumn<Model,String>company;
    public TableColumn<Model,Double> price;
    public TableColumn <Model,Double> diff;
    public TableColumn <Model,Double> buy;
    public TableColumn <Model,Double> sell;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        company.setCellValueFactory(new PropertyValueFactory<>("Company"));
        price.setCellValueFactory(new PropertyValueFactory<>("Price"));
        diff.setCellValueFactory(new PropertyValueFactory<>("Diff"));
        buy.setCellValueFactory(new PropertyValueFactory<>("Buy"));
        sell.setCellValueFactory(new PropertyValueFactory<>("Sell"));
        table.setItems(observableList);
    }
    ObservableList<Model> observableList= FXCollections.observableArrayList(
            new Model("ABC corp", 100.50, 2.50, 98.00, 105.00),
 new Model("XYZ Inc", 75.25, -1.75, 76.50, 73.00),
            new Model("MNO Ltd", 120.75, 3.25, 118.50, 123.00),
            new Model("PQR Co", 55.80, -0.80, 56.60, 55.00),
            new Model("LMN Industries", 90.25, 1.25, 89.00, 91.50)


    );


}


